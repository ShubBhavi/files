/*
 *
 */
package acceptancetests.runner;

import org.apache.commons.lang3.text.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aventstack.extentreports.service.ExtentService;

import acceptancetests.base.Context;
import acceptancetests.base.DriverUtil;
import acceptancetests.base.InvokeWebService;
import acceptancetests.base.OracleConfiguration;
import acceptancetests.base.StaticElementManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

/**
 * The Class Hook.
 */
public class Hook {

	/**
	 * After scenario.
	 *
	 * @param scenario the scenario
	 */

	/** The Constant LOG. */
	private final Logger LOG = LoggerFactory.getLogger(Hook.class);

	/** The driver manager. */
	private final DriverUtil driverManager = new DriverUtil();

	@After
	public void afterScenario(Scenario scenario) {
		OracleConfiguration.conection = null;
		System.out.println(scenario.getName() + " - " + scenario.getStatus());
	}

	/**
	 * Initialize test.
	 *
	 * @param scenario the scenario
	 * @throws Exception the exception
	 */
	@SuppressWarnings("deprecation")
	@Before
	public void InitializeTest(Scenario scenario) throws Exception {
		StaticElementManager.initalizeElementManager();
//		if (!StaticElementManager.isContains(Context.AUTHTOKEN) ) {
//			StaticElementManager.setContext(Context.AUTHTOKEN,InvokeWebService.getAuthToken());
//		}
		if (StaticElementManager.getContext(Context.FEATURENAME) != null) {
			if (!StaticElementManager.getContext(Context.FEATURENAME)
					.equals(WordUtils.capitalizeFully(scenario.getName()))) {
				StaticElementManager.staticWait(60);
				StaticElementManager.setContext(Context.FEATURENAME, WordUtils.capitalizeFully(scenario.getName()));
			}
		} else {
			StaticElementManager.setContext(Context.FEATURENAME, WordUtils.capitalizeFully(scenario.getName()));
//   ExtentService.getInstance().setSystemInfo("Test User", "ATAP USER");
			ExtentService.getInstance().setSystemInfo("Browser",
					System.getProperty("testautomation.browser").toString());
			ExtentService.getInstance().setSystemInfo("Operating System Type",
					System.getProperty("os.name").toString());
			ExtentService.getInstance().setSystemInfo("Web App Name",
					System.getProperty("testautomation.textname").toString());
//   ExtentService.getInstance().setSystemInfo("URL", System.getProperty("testautomation.targetWebUIUrl").toString());
			ExtentService.getInstance().setSystemInfo("Build version",
					System.getProperty("testautomation.version").toString());
//   ExtentService.getInstance().setUsingNaturalConf(usingNaturalConf);
		}

	}

	/**
	 * Process report.
	 *
	 * @param scenario the scenario
	 * @throws Exception the exception
	 */
}