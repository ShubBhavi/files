/**
 *
 */
package acceptancetests.runner;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Time;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.hamcrest.Matcher;
import org.openqa.selenium.WebDriver;

import acceptancetests.base.ExcelUtils;
import acceptancetests.base.StaticElementManager;
import io.cucumber.core.cli.Main;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClass {

	public static WebDriver driver;

	public static void createFeature(String TemplateName, String ApplicationName, String IntExt, String FeatureFilePath,
			ExcelUtils exUtil, String Env, String ServiceType, String RequestFileType, String ResponseFileType)
			throws IOException {
		String templatePath = System.getProperty("user.dir") + "\\src\\test\\resources\\" + TemplateName + ".feature";
		String[][] arrDetail = exUtil.getData("0", "1", ApplicationName.toString());
		String featureTemplate = "";
		try {
			Path tempPath = Paths.get(templatePath);
			featureTemplate = new String(Files.readAllBytes(tempPath));
			featureTemplate = featureTemplate.replaceAll("@<Application>", "@" + ApplicationName + IntExt);
			featureTemplate = featureTemplate.replaceAll("<Application>", ApplicationName);
			featureTemplate = featureTemplate.replaceAll("<URL>", IntExt);
			featureTemplate = featureTemplate.replaceAll("<Env>", Env);

			featureTemplate = featureTemplate.replaceAll("ServiceType", ServiceType);
			featureTemplate = featureTemplate.replaceAll("RequestFileType", RequestFileType);
			featureTemplate = featureTemplate.replaceAll("ResponseFileType", ResponseFileType);
			for (int j = 0; j < arrDetail.length; j++) {
				if (arrDetail[j][0].toString().equalsIgnoreCase("R")) {
					featureTemplate = featureTemplate + "|" + arrDetail[j][1].toString() + "|\r\n";
				}
			}
			if (IntExt.contains("External")) {
				IntExt = "2-" + IntExt;
			} else {
				IntExt = "1-" + IntExt;
			}
			BufferedWriter writer = new BufferedWriter(
					new FileWriter(FeatureFilePath + IntExt + "-" + ApplicationName.toString() + ".feature"));
			writer.write(featureTemplate);
			writer.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	static boolean deleteDirectory(File directoryToBeDeleted) {
		File[] allContents = directoryToBeDeleted.listFiles();
		if (allContents != null) {
			for (File file : allContents) {
				deleteDirectory(file);
			}
		}
		return directoryToBeDeleted.delete();
	}

	public static void main(String args[]) throws Throwable {
		ExcelUtils exUtil = new ExcelUtils(
				System.getProperty("user.dir") + "\\src\\test\\resources\\IIBScenarioMaster.xlsx", "Summary");
		String[][] arrSummary = new String[1][exUtil.getData("0", "0", "Summary").length];
		arrSummary = exUtil.getData("0", "8", "Summary");
		String FeatureFilePath = System.getProperty("user.dir") + "\\src\\test\\java\\acceptancetests\\features\\";
		// new File(FeatureFilePath).delete();
		// FileSystemUtils.deleteRecursively(new File(FeatureFilePath));
		deleteDirectory(new File(FeatureFilePath));
		// StaticElementManager.staticWait(6);
		Thread.sleep(3000);
		if (!new File(FeatureFilePath).exists()) {
			new File(FeatureFilePath).mkdirs();
		}
		// new File(FeatureFilePath).mkdirs();
		for (int i = 0; i < arrSummary.length; i++) {
			if (arrSummary[i][1].toString().equalsIgnoreCase("R")) {
				createFeature(arrSummary[i][5].toString(), arrSummary[i][0].toString(), "Internal", FeatureFilePath,
						exUtil, arrSummary[i][2].toString(), arrSummary[i][6].toString(), arrSummary[i][7].toString(),
						arrSummary[i][8].toString());
			}
			if (arrSummary[i][3].toString().equalsIgnoreCase("R")) {
				createFeature(arrSummary[i][5].toString(), arrSummary[i][0].toString(), "External", FeatureFilePath,
						exUtil, arrSummary[i][4].toString(), arrSummary[i][6].toString(), arrSummary[i][7].toString(),
						arrSummary[i][8].toString());
			}
		}
		System.out.println("Feature files are created.");
		try {
//			Response response = getCode();
//			String code = parseForOAuth2Code(response);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		try {
			Main.main(new String[] { "src/test/java/acceptancetests/features/", "-g", "acceptancetests.steps", "-g",
					"acceptancetests.runner", "-p",
					"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "-m" });
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Called Runner.");
		// postMethod();
		// filebinary();

	}

//	public static void postMethod() throws Exception {
//		RequestSpecification request = RestAssured.given();
//		request.baseUri("http://lt10eai22.bmwgroup.net:7080");
//
//		File testUploadFile = new File(
//				"C:\\CanadaAutomatedIIB\\CanadaAutomation\\src\\test\\resources\\PriceMaster.txt"); // Specify your own
//		System.out.println(System.currentTimeMillis());
//
//		Response response = request.given().header("Oemdlrcode", "1234").header("Oemshortcode", "BMCN")
//				.header("GUID", "017049").multiPart(testUploadFile).post("/PriceMasterPM");
//
//		System.out.println(System.currentTimeMillis());
//
////		Response response = request.given().header("Content-Type", "text/csv").and()
////				.body(IOUtils.toString(fileInputStream, "UTF-8")).when().post("/PriceMasterPM").then().statusCode(200)
////				.and().log().all().extract().response();
//
//		System.out.println(response.getStatusCode());
//		System.out.println(response.asString());
//	}

//	public static void filebinary() throws IOException {
//		InputStream inputStream = new FileInputStream(
//				"C:\\CanadaAutomatedIIB\\CanadaAutomation\\src\\test\\resources\\PriceMaster.txt");
//		byte[] foo = new byte[inputStream.available()];
//		inputStream.read(foo);
//		RequestSpecification request = RestAssured.given();
//		request.baseUri("http://lt10eai22.bmwgroup.net:7080");
//		long start = System.currentTimeMillis();
//		System.out.println(System.currentTimeMillis());
//		Response response = request.given().header("User-Agent", "RestAssured").header("Oemdlrcode", "1234")
//				.header("Oemshortcode", "BMCN").header("GUID", "017049").contentType("text/xml").body(foo).when()
//				.post("/PriceMasterPM");
//		System.out.println(System.currentTimeMillis() - start);
//		System.out.println(response.getStatusCode());
//		System.out.println(response.asString());
//	}

//	public static String getAuthToken() throws IOException {
////		InputStream inputStream = new FileInputStream(
////				"C:\\CanadaAutomatedIIB\\CanadaAutomation\\src\\test\\resources\\PriceMaster.txt");
////		byte[] foo = new byte[inputStream.available()];
////		inputStream.read(foo);
//		RequestSpecification request = RestAssured.given();
//		request.baseUri("https://auth-i.bmw.com/auth/oauth2/realms/root/realms/machine2machine");
//		long start = System.currentTimeMillis();
//		System.out.println(System.currentTimeMillis());
//		try {
//			Response response = request.given().auth().preemptive()
//					.basic("58abdad8-b275-4638-b490-8589c5b8d6d4", "MLA6ec0WSFryJazXwLdJa8fg4gwmp6xac1BjzO7R")
//					.header("User-Agent", "RestAssured").contentType("application/x-www-form-urlencoded").body("")
//					.when()
//					.post("/access_token?grant_type=client_credentials&scope=machine2machine%20client_58abdad8-b275-4638-b490-8589c5b8d6d4");
//
//			System.out.println(System.currentTimeMillis() - start);
//			System.out.println(response.getStatusCode());
//			System.out.println(response.asString());
//		} catch (Exception ex) {
//			System.out.println(ex.getMessage());
//		}
//		return null;
//	}

//	public static Response getAuthToken() throws IOException {
//		Response response = null;
//		try {
//			OkHttpClient client = new OkHttpClient().newBuilder().build();
//			MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
//			RequestBody body = RequestBody.create(mediaType, "");
//			Request request = new Request.Builder().url(
//					"https://auth-i.bmw.com/auth/oauth2/realms/root/realms/machine2machine/access_token?grant_type=client_credentials&scope=machine2machine%20client_58abdad8-b275-4638-b490-8589c5b8d6d4")
//					.method("POST", body).addHeader("Content-Type", "application/x-www-form-urlencoded")
//					.addHeader("Authorization",
//							"Basic NThhYmRhZDgtYjI3NS00NjM4LWI0OTAtODU4OWM1YjhkNmQ0Ok1MQTZlYzBXU0ZyeUphelh3TGRKYThmZzRnd21wNnhhYzFCanpPN1I=")
//					.addHeader("Cookie", "lbweni_dispatcher=2826383008.64288.0000").build();
//			response = client.newCall(request).execute();
//		} catch (Exception ex) {
//			System.out.println(ex.getMessage());
//		}
//		return response;
//	}

	public static String encode(String str1, String str2) {
		return new String(Base64.getEncoder().encode((str1 + ":" + str2).getBytes()));
	}

	public static Response getCode() {
		RestAssured.baseURI = "https://some-url.com";
		String authorization = encode("58abdad8-b275-4638-b490-8589c5b8d6d4",
				"MLA6ec0WSFryJazXwLdJa8fg4gwmp6xac1BjzO7R");
		RequestSpecification request = RestAssured.given();
		request.baseUri("https://auth-i.bmw.com/auth/oauth2/realms/root/realms/machine2machine");

		return request.given().header("authorization", "Basic " + authorization).contentType(ContentType.URLENC)
				.formParam("response_type", "code").queryParam("grant_type", "client_credentials")
				.queryParam("scope", "machine2machine%20client_58abdad8-b275-4638-b490-8589c5b8d6d4")
				.post("/access_token").then().statusCode(200).extract().response();
	}

	public static String parseForOAuth2Code(Response response) {
		return response.jsonPath().getString("access_token");
	}

}
