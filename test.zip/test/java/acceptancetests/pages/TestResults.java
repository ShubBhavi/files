/*
 *
 */
package acceptancetests.pages;

public class TestResults {

 private boolean isSuccess;
 private String statusCode;
 private String statusDesc;
 private boolean isMessageRefIdValid;
 private boolean isErrMessageRefIdValid;

 public String getStatusCode() {
  return statusCode;
 }

 public String getStatusDesc() {
  return statusDesc;
 }

 public boolean isErrMessageRefIdValid() {
  return isErrMessageRefIdValid;
 }

 public boolean isMessageRefIdValid() {
  return isMessageRefIdValid;
 }

 public boolean isSuccess() {
  return isSuccess;
 }

 public void setErrMessageRefIdValid(boolean isErrMessageRefIdValid) {
  this.isErrMessageRefIdValid = isErrMessageRefIdValid;
 }

 public void setMessageRefIdValid(boolean isMessageRefIdValid) {
  this.isMessageRefIdValid = isMessageRefIdValid;
 }

 public void setStatusCode(String statusCode) {
  this.statusCode = statusCode;
 }

 public void setStatusDesc(String statusDesc) {
  this.statusDesc = statusDesc;
 }

 public void setSuccess(boolean isSuccess) {
  this.isSuccess = isSuccess;
 }

}
