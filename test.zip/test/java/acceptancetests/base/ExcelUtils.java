/*
 *
 */
package acceptancetests.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * The Class ExcelUtilities.
 */
public class ExcelUtils {

 /** The filepath. */
 private final String filepath;
// private ArrayList cacheExcelData = new ArrayList();
 /** The Sheetname. */
 private final String Sheetname;

 /** The xinput. */
 // ************
 FileInputStream xinput = null;

 /** The xwb. */
 XSSFWorkbook xwb = null;

 /** The xsh. */
 XSSFSheet xsh = null;

 /**
  * Instantiates a new excel utilities.
  *
  * @param fPath  the f path
  * @param shName the sh name
  */
 public ExcelUtils(String fPath, String shName) {
  filepath = fPath;
  Sheetname = shName;
 }

 /**
  * Find cell.
  *
  * @param sData      the s data
  * @param iSearchCol the i search col
  * @param sCol       the s col
  * @param eCol       the e col
  * @return the string[][]
  * @throws IOException Signals that an I/O exception has occurred.
  */
 public ArrayList<String> findCell(String sData, int iSearchCol, int sCol, int eCol) throws IOException {
  final ArrayList<String> data = new ArrayList<>();
  int intR;
  FileInputStream input = null;

  input = new FileInputStream(filepath);
  try (XSSFWorkbook wb = new XSSFWorkbook(input)) {
	final XSSFSheet sh = wb.getSheet(Sheetname);
	  for (intR = 0; intR <= sh.getLastRowNum(); intR++) {
	
	   final XSSFRow row = sh.getRow(intR);
	   if (row.getCell(iSearchCol).toString().trim().replace(".0", "").equalsIgnoreCase(sData.trim())) {
	    for (int intC = sCol; intC <= eCol; intC++) {
	     if (row.getCell(intC).toString() != null) {
	      data.add(row.getCell(intC).toString());
	     }
	    }
	    break;
	   }
	  }
	  wb.close();
}
  if (input != null) {
   input.close();
  }

  return data;
 }

 public String[][] getData(String sCol, String eCol, String SheetName) throws IOException {

  int intR;
  int stCol = 0;
  FileInputStream input = null;
  String[][] data = null;
  input = new FileInputStream(filepath);
  final XSSFWorkbook wb = new XSSFWorkbook(input);
  for (int intS = 0; intS <= SheetName.split(";").length - 1; intS++) {
   final XSSFSheet sh = wb.getSheet(SheetName.split(";")[intS]);
   data = new String[sh.getLastRowNum()][Integer.parseInt(eCol.split(";")[intS])
     - Integer.parseInt(sCol.split(";")[intS]) + 1];
   for (intR = 1; intR <= sh.getLastRowNum(); intR++) {
    final XSSFRow row = sh.getRow(intR);
    stCol = 0;
    for (int intC = Integer.parseInt(sCol.split(";")[intS]); intC <= Integer.parseInt(eCol.split(";")[intS]); intC++) {
     if (row.getCell(intC).toString() != null) {
      data[intR - 1][stCol] = row.getCell(intC).toString();
     }
     stCol++;
    }
   }
//   if (intS == 0) {
//    StaticElementManager.setContext(Context.Sheet1, data);
//   } else {
//    StaticElementManager.setContext(Context.Sheet2, data);
//   }
  }
  wb.close();
  if (input != null) {
   input.close();
  }
  return data;
 }

}
