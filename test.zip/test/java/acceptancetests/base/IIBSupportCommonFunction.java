/*
 *
 */
package acceptancetests.base;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.custommonkey.xmlunit.DetailedDiff;
import org.custommonkey.xmlunit.XMLUnit;
import org.json.JSONObject;
import org.json.XML;
import org.junit.AssumptionViolatedException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * The Enum Context.
 */
public class IIBSupportCommonFunction {

	public static int TCID = 1;
	public static int RequestParam = 2;
	public static int GetPost = 5;
	public static int Url = 3;
	public static int ExternalUrl = 4;
	public static int Message_Table_Ref_ID = 5;
	public static int Error_Message_Table_Ref_ID = 6;
	public static int TestRefD = 7;
// public static int Expected_Response = 9;
	public static int Inbound = 8;
	public static int Outbound = 9;
	public static int Error = 10;
	public static int NodeDetailRequest = 11;
	public static int NodeDetailResponse = 12;
	public static int BodID = 13;
	public static int Parameter = 14;
	public static int MaxColNum = 14;
	public static String RowID = "";
	public static int JavaMaxColNum = 5;

	public static void addLogs(String msg) {
		// Reporter.addStepLog(msg + "<BR>");
		setTestRunnerOutput(msg);
	}

	public static String CreateErrorPopup(String ErrorMessage) {
		String ErrorString = "<a type='link' class='collapsible' onclick='opendiv();return false;'>Error Detail</a><div style='display:none' id='errorDetail'>"
				+ ErrorMessage
				+ "</div><script>function opendiv(){var coll = document.getElementsByClassName('collapsible');var i;for (i = 0; i < coll.length; i++) {  coll[i].addEventListener('click', function() {    this.classList.toggle('active');    var content = this.nextElementSibling; if (content.style.display == 'block') {      content.style.display = 'none';    } else {      content.style.display = 'block';    }  });}}</script>";
		return ErrorString;
	}

	static String getAlphaNumericString(int n) {
		// chose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789";
		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);
		for (int i = 0; i < n; i++) {
			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length() * Math.random());
			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}
		return sb.toString();
	}

	@SuppressWarnings("unchecked")
	public static ArrayList<String> getExcelRowData(String applicationCode, String strTestID, int maxCol) { // Making a
																											// new

//  || StaticElementManager.getContext(Context.ExcelRecord).toString().equals("[]")// // expected
		try {
			if (StaticElementManager.getContext(Context.ExcelRecord) == null
					|| (!((ArrayList<String>) StaticElementManager.getContext(Context.ExcelRecord))
							.get(IIBSupportCommonFunction.TCID).equals(strTestID))) {
				ExcelUtils exUtil = new ExcelUtils(
						System.getProperty("user.dir") + System.getProperty("testautomation.excelSheet"),
						applicationCode.trim());
				StaticElementManager.setContext(Context.ExcelRecord, exUtil.findCell(strTestID, 1, 0, maxCol));
			}
//   else {
//    if (!((ArrayList<String>) StaticElementManager.getContext(Context.ExcelRecord)).get(IIBSupportCommonFunction.TCID)
//      .equals(strTestID)) {
//     ExcelUtils exUtil = new ExcelUtils(
//       System.getProperty("user.dir") + System.getProperty("testautomation.excelSheet"), applicationCode.trim());
//     StaticElementManager.setContext(Context.ExcelRecord, exUtil.findCell(strTestID, 1, 0, maxCol));
//    }
//   }
		} catch (IOException e) {
			e.printStackTrace();
		}
		return (ArrayList<String>) StaticElementManager.getContext(Context.ExcelRecord);
	}

	public static String getExpectedIibResponse(String TCID, String NodeDetail, String fileType) {
		String expectedIibResponse = "";
		String expectedResDirPath = System.getProperty("user.dir")
				+ System.getProperty("testautomation.ResponseLocation");
		String expectedResponseFilePath = expectedResDirPath + "\\" + TCID + "." + fileType;
		String ReportResponsePath = System.getProperty("user.dir") + "\\target\\Result\\html\\Response\\";
		StaticElementManager.createScreenShotPath(ReportResponsePath);
		try {
			Path expectedResPath = Paths.get(expectedResponseFilePath);
			expectedIibResponse = new String(Files.readAllBytes(expectedResPath));
			expectedIibResponse = updateXML(expectedResponseFilePath, ReportResponsePath + TCID + "." + fileType,
					NodeDetail, expectedIibResponse);
			BufferedWriter writer = new BufferedWriter(new FileWriter(ReportResponsePath + TCID + "." + fileType));
			writer.write(expectedIibResponse);
			writer.close();
		} catch (Exception e) {
			setTestRunnerOutput("Exception at TestParams.getExpectedIibResponse() : " + e);
		}
		return expectedIibResponse;
	}

	public static String getFormatedString(String newValue) {
		if (newValue.contains("RowId") && RowID.equalsIgnoreCase("")) {
			RowID = getAlphaNumericString(2) + "-" + getAlphaNumericString(6);
		}
		return RowID;
	}

	public static String getIibRequest(String TCID, String NodeDetail, String fileType) throws Exception {
		String iibRequest = "";
		String iibReqDirPath = System.getProperty("user.dir") + System.getProperty("testautomation.RequestsLocation"); // "\\src\\test\\resources\\positiveRequests";
		String iibReqFilePath = iibReqDirPath + "\\" + TCID + "." + fileType;
		String ReportRequestPath = System.getProperty("user.dir") + "\\target\\Result\\html\\Request\\";
		StaticElementManager.createScreenShotPath(ReportRequestPath);
		try {
			Path iibReqPath = Paths.get(iibReqFilePath);
			iibRequest = new String(Files.readAllBytes(iibReqPath));
			if (fileType.equalsIgnoreCase("json")) {
				JSONObject json = new JSONObject(iibRequest);
				iibRequest = XML.toString(json);
			}
			iibRequest = updateXML(iibReqFilePath, ReportRequestPath + TCID + "." + fileType, NodeDetail, iibRequest);
			BufferedWriter writer = new BufferedWriter(new FileWriter(ReportRequestPath + TCID + "." + fileType));
			writer.write(iibRequest);
			writer.close();

		} catch (Exception e) {
			setTestRunnerOutput(TCID + "." + fileType + " is not available to be Processed");
			throw new AssumptionViolatedException(TCID + "." + fileType + " is not available to be Processed.");
		}
		setTestRunnerOutput("<b>Actual Input " + fileType + " request</b> : <a href='../html/Request/" + TCID + "."
				+ fileType + "' target=\"_blank\">" + TCID + "</a>");
		return iibRequest;
	}

	public static boolean jsonCompare(String leftJson, String rightJson) {
		Gson gson = new Gson();
		java.lang.reflect.Type type = new TypeToken<Map<String, Object>>() {
		}.getType();
		Map<String, Object> leftMap = gson.fromJson(leftJson, type);
		Map<String, Object> rightMap = gson.fromJson(rightJson, type);
		MapDifference<String, Object> mv = Maps.difference(leftMap, rightMap);
		if (mv.areEqual() || mv.entriesDiffering().size() == 2) {
			return true;
		} else {
			for (int iCnt = 0; iCnt < mv.entriesDiffering().size(); iCnt++) {
				if (!(mv.entriesDiffering().get(iCnt).toString().contains("refresh_date"))) {
					IIBSupportCommonFunction
							.addLogs(mv.entriesDiffering().get(iCnt).toString().split("- comparing")[0]);
				}
			}
			return false;
		}
	}

	public static void setTestRunnerOutput(String msg) {
		if (!(msg.contains("Pass -") || msg.contains("Fail -") || msg.contains("<table ><thead>"))) {
			msg = "&nbsp;&nbsp;&nbsp;&nbsp;" + msg;
		} else {
			msg = msg.replaceAll("Pass -", "<font style='color:#32cd32 !important'><b>Pass -</b></font>");
			msg = msg.replaceAll("Fail -", "<font style='color:red'><b>Fail -</b></font>");
		}
		msg = msg + "<BR>";
		ExtentCucumberAdapter.addTestStepLog(msg);
	}

	private static String updateElementValue(Document doc, String newValue, String strXML) {
//  Opportunity|RowId|XX-XXXXXX
		String ArrNodeList[] = newValue.split(",");
		for (int j = 0; j < ArrNodeList.length; j++) {
			String ArrNode[] = ArrNodeList[j].split(";");
			NodeList nodel = doc.getElementsByTagName(ArrNode[0]);
			Element nodeElement = null;
			// loop for each employee
			for (int i = 0; i < nodel.getLength(); i++) {
				nodeElement = (Element) nodel.item(i);
				Node name = nodeElement.getElementsByTagName(ArrNode[1]).item(0).getFirstChild();
				strXML = strXML.replaceAll("<" + ArrNode[1] + ">" + name.getNodeValue() + "</" + ArrNode[1] + ">",
						"<" + ArrNode[1] + ">" + getFormatedString(ArrNode[1]) + "</" + ArrNode[1] + ">");
			}
		}
		return strXML;
	}

	public static String updateXML(String iibPath, String ReportRequestXMLPath, String newValue, String strXML)
			throws TransformerConfigurationException, TransformerFactoryConfigurationError, TransformerException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		Document doc;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			InputStream inputStream = new FileInputStream(iibPath);
			Reader reader = new InputStreamReader(inputStream, "UTF-8");
			InputSource is = new InputSource(reader);
			is.setEncoding("UTF-8");
			doc = dBuilder.parse(is);
			doc.getDocumentElement().normalize();
			strXML = updateElementValue(doc, newValue, strXML);
		} catch (Exception e1) {
			// e1.printStackTrace();
		}
		return strXML;
	}

	/**
	 * Updating the respective attributevalue to newValue
	 *
	 * @param doc
	 */

	public static boolean xmlCompare(String ExpectedResponse, String ActualResponse) throws SAXException, IOException {
		boolean returnValue = false;
		XMLUnit.setIgnoreWhitespace(true);
		XMLUnit.setIgnoreAttributeOrder(true);

		DetailedDiff diff = new DetailedDiff(XMLUnit.compareXML(ExpectedResponse, ActualResponse));
		List<?> allDifferences = diff.getAllDifferences();
		if ((1 == allDifferences.size() && allDifferences.get(0).toString().contains("CreationDateTime"))
				|| allDifferences.size() == 0) {
			returnValue = true;
		} else {
			for (int i = 0; i < allDifferences.size(); i++) {
				if (!(allDifferences.get(i).toString().contains("CreationDateTime"))) {
					IIBSupportCommonFunction.addLogs(allDifferences.get(i).toString().split("- comparing")[0]);
				}
			}
		}
		// to do list.
		return returnValue;
	}

	private IIBSupportCommonFunction() {
	}

}
