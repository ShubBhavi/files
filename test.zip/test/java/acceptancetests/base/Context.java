/*
 *
 */
package acceptancetests.base;

/**
 * The Enum Context.
 */
public enum Context {

 /** The header. */
 HEADER,
 /** The headerimage. */
 HEADERIMAGE, HANDDLE, Sheet1, Sheet2, ExcelRecord
 /** The vehicle info on addvehiclearray. */
 ,FEATURENAME, AUTHTOKEN

 /**
  * @param intS
  * @return
  */

}
