/*
 *
 */
package acceptancetests.base;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import io.cucumber.java.Scenario;

/**
 * The Class StaticElementManager.
 */
public class StaticElementManager {

 /** The Constant LOG. */
 private static final Logger LOG = LoggerFactory.getLogger(StaticElementManager.class);

 /** The g driver. */
 private static WebDriver gDriver;

 /** The g wait. */
 private static WebDriverWait gWait;

 /** The g JS. */
 private static JavascriptExecutor gJS;

 /** The scenario context. */
 private static Map<String, Object> scenarioContext;

 /** The page object manager. */
// private static PageObjectManager pageObjectManager;

 /** The i wait interval. */
 private static long iWaitInterval = Long.parseLong(System.getProperty("testautomation.implicitlyWait"));
 public static String DownloadLocation = "";

 /**
  * Button verification.
  *
  * @param locator the locator
  * @param text    the text
  * @return the boolean
  */
 public static Boolean buttonVerification(By locator, String text) {
  gWait.until(ExpectedConditions.elementToBeClickable(locator));
  final String realvalue = getElement(locator).getText();
  return realvalue.equalsIgnoreCase(text);
 }

 public static void captureAndDisplayScreenShot() {
  if (((RemoteWebDriver) gDriver).getSessionId() != null) {
   String current = "";
   final String filename = "failed";
   final String extentReportImage = System.currentTimeMillis() + "_" + filename + ".png";
   String strScreenShotFolder = "";
   String location = "";
   try {
    current = new java.io.File(".").getCanonicalPath();
   } catch (final IOException e) {
    logMessage(e.getMessage());
   }
   if (current.contains("/")) {
    location = current + "/target/Result/html/Screenshots/";
    strScreenShotFolder = "Screenshots/";
   } else {
    location = current + "\\target\\Result\\html\\Screenshots\\";
    strScreenShotFolder = "Screenshots\\";
   }
   createScreenShotPath(location);
   try {

    ((TakesScreenshot) StaticElementManager.getDriver()).getScreenshotAs(OutputType.FILE);
    ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(strScreenShotFolder + extentReportImage, "");
    // Reporter.addScreenCaptureFromPath(strScreenShotFolder + extentReportImage);
   } catch (final IOException e) {
    if (e.toString().contains("unexpected alert open")) {
     try {
      final BufferedImage image = new Robot()
        .createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
      ImageIO.write(image, "png", new File(extentReportImage));
      ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(extentReportImage, "");
      // Reporter.addScreenCaptureFromPath(extentReportImage);
      final Alert alert = gDriver.switchTo().alert();
      alert.accept();
     } catch (final AWTException e1) {
      logMessage(e1.getMessage());
     } catch (final IOException e1) {
      logMessage(e1.getMessage());
     }
    }
   }
  }
 }

 /**
  * Capture and display screen shot.
  *
  * @param filename the filename
  */
 public static void captureAndDisplayScreenShot(Scenario scenario, File src) {
  if (((RemoteWebDriver) gDriver).getSessionId() != null) {
   String current = "";
   final String filename = scenario.getStatus().toString();
   final String extentReportImage = System.currentTimeMillis() + "_" + filename + ".png";
   String strScreenShotFolder = "";
   String location = "";
   try {
    current = new java.io.File(".").getCanonicalPath();
   } catch (final IOException e) {
    logMessage(e.getMessage());
   }
   if (current.contains("/")) {
    location = current + "/target/Result/html/Screenshots/";
    strScreenShotFolder = "Screenshots/";
   } else {
    location = current + "\\target\\Result\\html\\Screenshots\\";
    strScreenShotFolder = "Screenshots\\";
   }
   createScreenShotPath(location);
   try {

    if (scenario.getStatus().toString().equalsIgnoreCase("failed")) {
     final byte[] screenshot = FileUtils.readFileToByteArray(src);
     scenario.attach(screenshot, "image/png", "Screenshot attached"); // ... and embed it in the
    }
    // now copy the screenshot to desired location using copyFile method

    // Files.copy(src, new File(location + extentReportImage));
    ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(strScreenShotFolder + extentReportImage, "");
    // Reporter.addScreenCaptureFromPath(strScreenShotFolder + extentReportImage);
   } catch (final IOException e) {
    if (e.toString().contains("unexpected alert open: {Alert text : Delete the selected Retail(s)")) {
     try {
      final BufferedImage image = new Robot()
        .createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
      ImageIO.write(image, "png", new File(extentReportImage));
      ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(extentReportImage, "");
      // Reporter.addScreenCaptureFromPath(extentReportImage);
      final Alert alert = gDriver.switchTo().alert();
      alert.accept();
     } catch (final AWTException e1) {
      logMessage(e1.getMessage());
     } catch (final IOException e1) {
      logMessage(e1.getMessage());
     }
    }
   }
  }
 }

 /**
  * Click using js.
  *
  * @param elementLocator the element locator
  */
 public static void clickUsingJs(By elementLocator) {
  try {
   // staticWait(2);
   gWait.until(ExpectedConditions.elementToBeClickable(elementLocator));
   getElement(elementLocator).click();
  } catch (final WebDriverException we) {

   gJS.executeScript("arguments[0].click()", getElement(elementLocator));
  }
  staticWait(2);
 }

 /**
  * Click using js.
  *
  * @param elementLocator the element locator
  */
 public static void clickUsingJs(WebElement elementLocator) {
  try {
   // staticWait(2);
   gWait.until(ExpectedConditions.elementToBeClickable(elementLocator));
   elementLocator.click();
  } catch (final WebDriverException we) {
   LOG.info(elementLocator.toString() + " Could not be clicked, trying with Javascript executer now.");
   gJS.executeScript("arguments[0].click()", elementLocator);
  }
  staticWait(2);
 }

 /**
  * This function verifies whether user has landed on newly opened tab based on
  * argument passed as part of title of page and closes the new tab. After this,
  * the focus is returned back to original tab.
  *
  * @throws InterruptedException the interrupted exception
  */
 public static void closeNewlyOpenedTab() throws InterruptedException {
  if (gDriver.getWindowHandles().size() > 1) {
   final String originalHandle = getContext(Context.HANDDLE).toString();
   staticWait(8);
   for (final String handle : gDriver.getWindowHandles()) {
    if (!handle.equals(originalHandle)) {
     captureAndDisplayScreenShot();
     gDriver.switchTo().window(handle);
     gDriver.close();
    }
   }
   gDriver.switchTo().window(originalHandle);
  }
 }

 /**
  * Creates the screen shot path.
  *
  * @param sPath the s path
  */
 public static void createScreenShotPath(String sPath) {
  if (!new File(sPath).exists()) {
   new File(sPath).mkdirs();
  }
 }

 public static void customcaptureAndDisplayScreenShot() throws HeadlessException, AWTException {
  if (((RemoteWebDriver) gDriver).getSessionId() != null) {
   String current = "";
   final String extentReportImage = System.currentTimeMillis() + ".png";
   String location = "";
   try {
    current = new java.io.File(".").getCanonicalPath();
   } catch (final IOException e) {
    logMessage(e.getMessage());
   }
   if (current.contains("/")) {
    location = current + "/target/Result/html/Screenshots/";
   } else {
    location = current + "\\target\\Result\\html\\Screenshots\\";
   }
   createScreenShotPath(location);
   try {

    final BufferedImage image = new Robot()
      .createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));

    ImageIO.write(image, "png", new File(location + extentReportImage));
    ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(extentReportImage, "");
    // Reporter.addScreenCaptureFromPath(extentReportImage);
   } catch (final IOException e) {
    if (e.toString().contains("unexpected alert open: {Alert text : Delete the selected Retail(s)")) {
     try {
      final BufferedImage image = new Robot()
        .createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
      ImageIO.write(image, "png", new File(extentReportImage));
      ExtentCucumberAdapter.addTestStepScreenCaptureFromPath(extentReportImage, "");
      // Reporter.addScreenCaptureFromPath(extentReportImage);
      final Alert alert = gDriver.switchTo().alert();
      alert.accept();
     } catch (final AWTException e1) {
      logMessage(e1.getMessage());
     } catch (final IOException e1) {
      logMessage(e1.getMessage());
     }
    }
   }
  }
 }

 public static boolean DisplayElement(By locator) {
  gWait.until(ExpectedConditions.visibilityOf(getElement(locator)));
  return getElement(locator).isDisplayed();
 }

 public static boolean DisplayElement(WebElement locator) {
  gWait.until(ExpectedConditions.visibilityOf(locator));
  return locator.isDisplayed();
 }

 public static boolean DisplayElements(By locator) {
  gWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
  return getElement(locator).isDisplayed();
 }

 public static boolean ElementPresence(By Locator) {
  boolean returevalue = false;
  StaticElementManager.updateGWait(5);
  try {
   getElement(Locator);
   returevalue = true;
  } catch (final Exception e) {
  }
  resetGWait();
  return returevalue;
 }

 public static boolean ElementsPresence(By Locator) {
  boolean returevalue = false;
  StaticElementManager.updateGWait(5);
  try {
   getElements(Locator);
   returevalue = true;
  } catch (final Exception e) {
  }
  resetGWait();
  return returevalue;
 }

 public static int generateRandomNumber(int max, int min) {
  final Random rand = new Random();
  // nextInt as provided by Random is exclusive of the top value so you need to
  // add 1
  return rand.nextInt(max - min + 1) + min;
 }

 /**
  * Gets the context.
  *
  * @param skey the skey
  * @return the context
  */
 public static Object getContext(Context skey) {
  Object obj = null;
  try {
   obj = scenarioContext.get(skey.toString());
  } catch (final NullPointerException ex) {
   obj = "";
  }
  return obj;
 }

 public static String getCurrentDate() {
  final SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
  final Date date = new Date(System.currentTimeMillis());
  return formatter.format(date);
 }

 /**
  * Gets the driver.
  *
  * @return the driver
  */
 public static WebDriver getDriver() {
  return gDriver;
 }

 // Comment This Function is created to control the creation of any
 // webElement
 /**
  * Gets the element.
  *
  * @param locator the locator
  * @return the element
  */
 // and also apply any wait in a single place. cr
 public static WebElement getElement(By locator) {
  gWait.until(ExpectedConditions.presenceOfElementLocated(locator));
  return gDriver.findElement(locator);
 }

 /**
  * Gets the element.
  *
  * @param elemt   the elemt
  * @param locator the locator
  * @return the element
  */
 public static WebElement getElement(WebElement elemt, By locator) {
  gWait.until(ExpectedConditions.presenceOfNestedElementLocatedBy(elemt, locator));
  return elemt.findElement(locator);
 }

 // Comment This Function is created to control the creation of any
 // webElements
 /**
  * Gets the elements.
  *
  * @param locator the locator
  * @return the elements
  */
 // List and also apply any wait in a single place. cr
 public static List<WebElement> getElements(By locator) {
  gWait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
  return gDriver.findElements(locator);
 }

 /**
  * Gets the elements.
  *
  * @param elemt   the elemt
  * @param locator the locator
  * @return the elements
  */
 public static List<WebElement> getElements(WebElement elemt, By locator) {
  gWait.until(ExpectedConditions.presenceOfNestedElementLocatedBy(elemt, locator));

  return elemt.findElements(locator);
 }

 /**
  * Gets the GCI D in REST.
  *
  * @return the GCI D in REST
  */
 public static String getGCID_in_REST() {
  final String REST_gcId = System.getProperty("testautomation.targetRestGCID");
  if (REST_gcId == null || REST_gcId.isEmpty()) {
   logMessage("The GCID for delinking user from group was not specified or is empty in ");
  }
  return REST_gcId;
 }

 /**
  * Gets the group I D in REST.
  *
  * @return the group I D in REST
  */
 public static String getGroupID_in_REST() {
  final String REST_groupId = System.getProperty("testautomation.targetRestGroupID");
  if (REST_groupId == null || REST_groupId.isEmpty()) {
   logMessage("The GroupId for delinking user from group was not specified or is empty in ");
  }
  return REST_groupId;
 }

 /**
  * Gets the page object manager.
  *
  * @return the page object manager
  */
// public static PageObjectManager getPageObjectManager() {
//  return pageObjectManager == null ? new PageObjectManager() : pageObjectManager;
// }

 /**
  * Gets the js.
  *
  * @return the js
  */
 public static JavascriptExecutor getJS() {
  return gJS;
 }

 /**
  * Gets the target rest url.
  *
  * @return the target rest url
  */
 public static String getTargetRestUrl() {
  final String targetRestApiUrl = System.getProperty("testautomation.targetRestApiUrl");
  if (targetRestApiUrl == null || targetRestApiUrl.isEmpty()) {
   logMessage("The REST API url of the target test application was not specified or is empty in ");
  }
  return targetRestApiUrl;
 }

 /**
  * Gets the target web URL.
  *
  * @return the target web URL
  */
 public static String getTargetWebURL() {
  String targetWebUIUrl = System.getProperty("testautomation.targetWebUIUrl");
  if ("false".equals(System.getProperty("testautomation.AuthHub"))) {
   targetWebUIUrl = targetWebUIUrl + "/login.html";
  }
  if (targetWebUIUrl == null || targetWebUIUrl.isEmpty()) {
   logMessage("The UI url of the target test application was not specified or is empty in ");
  }
  return targetWebUIUrl;

 }

 public static String getText(By locator) {
  // updateGWait(5);
  try {
   scrollingVerticallyByRelativeCoordinates(locator, 100);
  } catch (final Exception ex) {
  }
  try {
   gWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
  } catch (final Exception ex) {
  }
  // resetGWait();
  return getElement(locator).getText();
 }

 public static String getText(WebElement locator) {
  try {
   updateGWait(10);
   scrollingVerticallyByRelativeCoordinates(locator, 100);
   gWait.until(ExpectedConditions.visibilityOf(locator));
  } catch (final Exception ex) {
  }
  resetGWait();
  return locator.getText();
 }

 /**
  * Gets the wait.
  *
  * @return the wait
  */
 public static WebDriverWait getWait() {
  return gWait;
 }

 /**
  * This method returns the title of the current page.
  *
  * @return pageTitle String format
  */
 public static String getWindowTitle() {
  return gDriver.getTitle();
 }

 public static void initalizeElementManager() {
  if (scenarioContext == null) {
   scenarioContext = new HashMap<>();
  }
 }

 /**
  * Initalize element manager.
  *
  * @param driver   the driver
  * @param viewMode the view mode
  */
 public static void initalizeElementManager(WebDriver driver, String viewMode) {
  gDriver = driver;
  gWait = new WebDriverWait(gDriver, iWaitInterval);
  gJS = (JavascriptExecutor) gDriver;
  scenarioContext = new HashMap<>();
  gDriver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
  gDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  setContext(Context.HANDDLE, gDriver.getWindowHandle());
 }

 /**
  * Checks if is contains.
  *
  * @param featurename the skey
  * @return the boolean
  */
 public static Boolean isContains(Context featurename) {
  try {
   return scenarioContext.containsKey(featurename);
  } catch (final NullPointerException npe) {
   return false;
  }
 }

 public static File lastFileModified(String dir) {
  try {
   Thread.sleep(5000);
  } catch (final InterruptedException e) {
// TODO Auto-generated catch block
   e.printStackTrace();
  }
  final File fl = new File(dir);
  final File[] files = fl.listFiles((FileFilter) file -> file.isFile());
  long lastMod = Long.MIN_VALUE;
  File choice = null;
  for (final File file : files) {
   if (file.lastModified() > lastMod) {
    choice = file;
    lastMod = file.lastModified();
   }
  }

// File file = new File(home+"/Downloads/" + fileName + ".txt");

  return choice;
 }

 /**
  * Launchanothertab.
  *
  * @param sURL the s URL
  */
 public static void launchanothertab(String sURL) {
  final String scriptToExecute = "window.open('".concat(sURL).concat("','_blank');");
  gJS.executeScript(scriptToExecute);
  String subWindowHandler = null;
  final Set<String> handles = gDriver.getWindowHandles();
  final Iterator<String> iterator = handles.iterator();
  while (iterator.hasNext()) {
   subWindowHandler = iterator.next();
  }
  gDriver.switchTo().window(subWindowHandler);
 }

 /**
  * Link click.
  *
  * @param locator the locator
  */
 public static void linkClick(By locator) {
  clickUsingJs(locator);
 }

 /**
  * Log message.
  *
  * @param msg the msg
  */
 public static void logMessage(String msg) {
  LOG.debug(msg);
 }

 /**
  * Quit driver.
  */
 public static void quitDriver() {
  gDriver.quit();
 }

 /**
  * Random txt.
  *
  * @param n the n
  * @return the string
  */
 public static String randomTxt(int n) {
  final String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
  final StringBuilder substring = new StringBuilder(n);
  for (int i = 0; i < n; i++) {
   final int index = (int) (AlphaNumericString.length() * Math.random());
   substring.append(AlphaNumericString.charAt(index));
  }
  return substring.toString();
 }

 /**
  * Reset G wait.
  */
 public static void resetGWait() {
  gWait = new WebDriverWait(gDriver, iWaitInterval);
  gDriver.manage().timeouts().implicitlyWait(iWaitInterval, TimeUnit.SECONDS);
 }

 /**
  * Scroll by coordinates.
  *
  * @param X the x
  * @param Y the y
  */
 public static void scrollByCoordinates(int X, int Y) {
  gJS.executeScript("window.scrollTo(" + X + ", " + Y + ")");
 }

 /**
  * Scrolling vertically by relative coordinates.
  *
  * @param locator   the locator
  * @param relativeY the relative Y
  */
 public static void scrollingVerticallyByRelativeCoordinates(By locator, int relativeY) {
  try {
   Point p = getElement(locator).getLocation();
   scrollByCoordinates(0, p.getY() - relativeY);
   p = null;
  } catch (final WebDriverException ex) {

  }
 }

 /**
  * Scrolling vertically by relative coordinates.
  *
  * @param element   the element
  * @param relativeY the relative Y
  */
 public static void scrollingVerticallyByRelativeCoordinates(WebElement element, int relativeY) {
  try {
   Point p = element.getLocation();
   scrollByCoordinates(0, p.getY() - relativeY);
   p = null;
  } catch (final WebDriverException ex) {

  }
 }

 /**
  * Select drop down value.
  *
  * @param dropDown    the drop down
  * @param selectValue the select value
  */
 public static void selectDropDownValue(By dropDown, String selectValue) {
  staticWait(1);
  clickUsingJs(dropDown);
  int count = 0;
  while (getElement(
    By.xpath("//li[@class='ui-menu-item']//div[contains(text(),'" + selectValue + "')]/parent::li/parent::ul"))
      .getAttribute("aria-hidden").equalsIgnoreCase("true")
    && count < 30) {
   staticWait(1);
   count++;
  }
  getElement(dropDown).sendKeys(selectValue + Keys.ENTER);
 }

 /**
  * Select value in drop down indirectly.
  *
  * @param parent the parent
  * @param child  the child
  * @param value  the value
  * @return true, if successful
  */
 public static boolean selectValueInDropDownIndirectly(By parent, By child, String value) {
  staticWait(1);
  gWait.until(ExpectedConditions.visibilityOfElementLocated(parent));
  final WebElement parentElement = getElement(parent);
  boolean matchFound = false;
  final Point p1 = parentElement.getLocation();
  scrollByCoordinates(0, p1.getY() - 400);
  clickUsingJs(parentElement);
  final List<WebElement> childElements = getElements(parentElement, child);
  for (final WebElement elem : childElements) {
   if (elem.getText().equalsIgnoreCase(value)) {
    elem.getLocation();
    gWait.until(ExpectedConditions.attributeContains(getElement(elem, By.xpath("parent::ul")), "aria-hidden", "false"));
    clickUsingJs(elem);
    matchFound = true;
    break;
   }
  }
  return matchFound;
 }

 /**
  * Select vehicle purchase date for owner.
  *
  * @param strMonth the str month
  * @param strDay   the str day
  * @param strYear  the str year
  */
 public static void selectVehiclePurchaseDateForOwner(String strMonth, final String strDay, final String strYear) {
  final By spanMonth = By.id("month-button");
  final By spanDay = By.id("day-button");
  final By spanYear = By.id("year-button");
  if (!strMonth.isEmpty()) {
   strMonth = WordUtils.capitalizeFully(Month.of(Integer.parseInt(strMonth)).name().substring(0, 3));
   selectDropDownValue(spanMonth, strMonth);
  }
  if (!strDay.isEmpty()) {
   selectDropDownValue(spanDay, strDay);
  }
  if (!strYear.isEmpty()) {
   selectDropDownValue(spanYear, strYear);
  }
 }

 /**
  * Sets the context.
  *
  * @param key   the key
  * @param value the value
  */
 public static void setContext(Context key, Object value) {
  scenarioContext.put(key.toString(), value);
 }

 public static void setData(By elementLocator, String data) {
  WebElement textControl = null;
  try {
   getWait().until(ExpectedConditions.presenceOfElementLocated(elementLocator));
   textControl = getElement(elementLocator);
   textControl.clear();
   textControl.sendKeys(data);
  } catch (final WebDriverException we) {
   LOG.info(elementLocator.toString() + " Could not be clicked, trying with Javascript executer now.");
   gJS.executeScript("arguments[0].value='" + data + "';", textControl);
  }

 }

 public static void setDriver() {
  gDriver = null;
 }

 public static void setFrameFromCurrent(By frameElement) {
  gDriver.switchTo().frame(StaticElementManager.getElement(frameElement));
  staticWait(1);
 }

 public static void setFrameFromCurrent(String frameElement) {
  gDriver.switchTo().frame(frameElement);
  staticWait(1);
 }

 public static void setFrameToDefault() {
  // staticWait(1);
  gDriver.switchTo().defaultContent();
  staticWait(1);
 }

 /**
  * Static wait.
  *
  * @param multiplier the multiplier
  */
 public static void staticWait(long multiplier) {
  try {
   Thread.sleep(500 * multiplier);
  } catch (final InterruptedException e) {

  }
 }

 /**
  * Text verification.
  *
  * @param locator the locator
  * @param text    the text
  * @return the boolean
  */
 public static Boolean textVerification(By locator, String text) {
  gWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
  final String realvalue = getElement(locator).getText();
  return realvalue.equalsIgnoreCase(text);
 }

 /**
  * Update G wait.
  *
  * @param iWaitInSec the i wait in sec
  */
 public static void updateGWait(int iWaitInSec) {
  gWait = new WebDriverWait(gDriver, iWaitInSec);
  gDriver.manage().timeouts().implicitlyWait(iWaitInSec, TimeUnit.SECONDS);
 }

 /**
  * This method compares the Title of the page with expected Title.
  *
  * @param expectedTitle String
  * @return String - If empty, it means the expected and actual Title match for
  *         page. Otherwise, it returns the title of page currently displayed
  */
 public static String verifyWindowTitle(String expectedTitle) {
  final String pageTitle = getWindowTitle();
  return expectedTitle.contains(pageTitle) || pageTitle.contains(expectedTitle) ? pageTitle : "";
 }

 public static void waitForNumberOfWindowsToEqual(final int numberOfWindows) { // Making a new expected condition
  gWait.until(driver -> gDriver.getWindowHandles().size() >= numberOfWindows);

 }

 /**
  * Instantiates a new static element manager.
  */
 private StaticElementManager() {
 }
}
