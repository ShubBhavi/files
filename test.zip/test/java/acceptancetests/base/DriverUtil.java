/*
 *
 */
package acceptancetests.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.cucumber.java.Scenario;

/**
 * The Class DriverUtil.
 *
 * @author QXY4826
 */
public final class DriverUtil {
 private final Logger LOG = LoggerFactory.getLogger(DriverUtil.class);
 /** The obj. */
 private DriverUtil obj = null;
 public long DEFAULT_WAIT = 20;
 /** The options. */
 ChromeOptions options;

 /** The conf file. */
 private final String confFile = "src/test/resources/testautomation.properties";

 /** The driver. */
 private WebDriver driver;

 /** The selenium box url. */
 private String seleniumBoxUrl;

 /** The selenium box token. */
 private String seleniumBoxToken;

 /** The target rest api url. */
 private String targetRestApiUrl;

 /** The implicitly wait. */
 private String implicitlyWait;

 /** The conditional wait. */
 private String conditionalWait;

 /** The browser. */
 private String browser = "chrome";

 /** The machine. */
// private  String machine;

 /** The RES T gc id. */
 private String REST_gcId;

 /** The RES T group id. */
 private String REST_groupId;

 private String PROXY;

 {
  loadSystemProperties();
  // initialize the Selenium Box Url
  seleniumBoxUrl = System.getProperty("testautomation.seleniumBoxUrl");
  // initialize the Selenium Box token
  seleniumBoxToken = System.getProperty("testautomation.seleniumBoxToken");
  // initialize the UI Url
  // initialize the REST API Url
  targetRestApiUrl = System.getProperty("testautomation.targetRestApiUrl");
  // initialize which browser to use
  browser = System.getProperty("testautomation.browser");
  if ("".equals(browser) || browser == null) {
   StaticElementManager.logMessage("The browser was not specified in " + confFile);
   System.exit(0);
  }
  // here the browser can be overwritten with the one defined in Jenkins
  // for example
  final String envbrowser = System.getenv("BROWSER");
  if (!"".equals(envbrowser) && envbrowser != null) {
   browser = envbrowser;
  }
//Set proxy in Selenium box
  PROXY = System.getProperty("testautomation.proxy");
  // initialize how much waiting time needs to be applied for all elements
  // on page
  implicitlyWait = System.getProperty("testautomation.implicitlyWait");
  // initialize how much waiting time needs to be applied for waiting
  // condition on an apllied before any action is taken on it
  conditionalWait = System.getProperty("testautomation.conditionalWait");
  // initialize the machine (Local or SeleniumBox) on which scripts
  // are to be executed
  // machine = System.getProperty("testautomation.machine");
  /* ------ Initializing REST API variables ------- */
  REST_gcId = System.getProperty("testautomation.targetRestGCID");
  REST_groupId = System.getProperty("testautomation.targetRestGroupID");
 }

 public void closeDriver() {
  if (driver != null) {
   try {
    driver.quit();
    driver = null;
   } catch (NoSuchMethodError | NoSuchSessionException | SessionNotCreatedException ex) {
    ex.printStackTrace();
    LOG.info("An error occured while closing the driver: ", ex);
   }
  }
 }

 /**
  * Gets the browser.
  *
  * @return the browser
  */
 public String getBrowser() {
  return browser;
 }

 /**
  * Gets the conditional wait.
  *
  * @return the conditional wait
  */
 public long getConditionalWait() {
  if (conditionalWait == null || conditionalWait.isEmpty()) {
   StaticElementManager.logMessage("Conditional Wait was not specified or is empty in " + confFile);
   return 30;
  } else {
   try {
    return Long.parseLong(conditionalWait);
   } catch (final NumberFormatException e) {
    throw new RuntimeException("Not able to parse value : " + conditionalWait + " in to Long");
   }
  }
 }

 /**
  * Gets the desired capabilities.
  *
  * @return the desired capabilities
  */
 private DesiredCapabilities getDesiredCapabilities() {
  DesiredCapabilities ret = null;
  final String preferredDriver = getBrowser().toLowerCase();
  switch (preferredDriver.toLowerCase()) {
  case "safari":
   ret = DesiredCapabilities.safari();
   break;
  case "msie":
   ret = DesiredCapabilities.internetExplorer();
   break;
  case "edge":
   ret = DesiredCapabilities.edge();
   break;
  case "chrome":
   ret = DesiredCapabilities.chrome();
   break;
  default:
   ret = DesiredCapabilities.firefox();
   break;
  }
  return ret;
 }

 /**
  * Gets the driver.
  *
  * @return the driver
  */
 public WebDriver getDriver() {
  return driver;
 }

 /**
  * Gets the GCI D in REST.
  *
  * @return the GCI D in REST
  */
 public String getGCID_in_REST() {
  if (REST_gcId == null || REST_gcId.isEmpty()) {
   StaticElementManager
     .logMessage("The GCID for delinking user from group was not specified or is empty in ".concat(confFile));
  }
  return REST_gcId;
 }

 /**
  * Gets the group I D in REST.
  *
  * @return the group I D in REST
  */
 public String getGroupID_in_REST() {
  if (REST_groupId == null || REST_groupId.isEmpty()) {
   StaticElementManager
     .logMessage("The GroupId for delinking user from group was not specified or is empty in " + confFile);
  }
  return REST_groupId;
 }

 /**
  * Gets the implicitly wait.
  *
  * @return the implicitly wait
  */
 public long getImplicitlyWait() {
  if (implicitlyWait == null || implicitlyWait.isEmpty()) {
   StaticElementManager.logMessage("Implicit Wait was not specified or is empty in " + confFile);
   return 30;
  } else {
   try {
    return Long.parseLong(implicitlyWait);
   } catch (final NumberFormatException e) {
    throw new RuntimeException("Not able to parse value : " + implicitlyWait + " in to Long");
   }
  }
 }

 /**
  * Gets the single instance of DriverManager.
  *
  * @return single instance of DriverManager
  */
 public DriverUtil getInstance() {
  if (obj == null) {
   obj = new DriverUtil();
  }
  return obj;
 }

 /**
  * Gets the selenium box token.
  *
  * @return the selenium box token
  */
 private String getSeleniumBoxToken() {
  if (seleniumBoxToken == null || seleniumBoxToken.isEmpty()) {
   StaticElementManager.logMessage("The Selenium Box token was not specified or is empty in " + confFile);
  }
  return seleniumBoxToken;
 }

 /**
  * Gets the selenium box url.
  *
  * @return the selenium box url
  */
 public String getSeleniumBoxUrl() {
  if (seleniumBoxUrl == null || seleniumBoxUrl.isEmpty()) {
   StaticElementManager.logMessage("The Selenium Box URL was not specified or is empty in " + confFile);
  }
  return seleniumBoxUrl;
 }

 /**
  * Gets the target rest url.
  *
  * @return the target rest url
  */
 public String getTargetRestUrl() {
  if (targetRestApiUrl == null || targetRestApiUrl.isEmpty()) {
   StaticElementManager
     .logMessage("The REST API url of the target test application was not specified or is empty in " + confFile);
  }
  return targetRestApiUrl;
 }

 public String getTestName() {
  if (System.getProperty("testautomation.textname") == null
    || System.getProperty("testautomation.textname").isEmpty()) {
   return "Automation Script Testing";
  }
  return System.getProperty("testautomation.textname");
 }

 /**
  * Inits the driver.
  *
  * @param scenario the scenario
  * @return the web driver
  * @throws MalformedURLException
  */
 public WebDriver initDriver(Scenario scenario, boolean bProxy) throws MalformedURLException {

  final String TestMachine = System.getProperty("testautomation.machine");
  if (TestMachine.equalsIgnoreCase("remote")) {

   String buildnr = System.getenv("BUILD_NUMBER");
   if ("".equals(buildnr) || buildnr == null) {
    buildnr = "" + System.currentTimeMillis();
   }
   System.out.println("Build nr:" + buildnr);

   DesiredCapabilities capabilities = null;
   capabilities = getDesiredCapabilities();
   capabilities.setJavascriptEnabled(true);
   capabilities.setCapability("takesScreenshot", true);
   capabilities.setCapability("browserName", getBrowser());
   capabilities.setCapability("e34:l_testName", getTestName());
   capabilities.setCapability("e34:video", true);
   capabilities.setCapability("e34:token", getSeleniumBoxToken());
   capabilities.setCapability("build", "Build-" + buildnr);
   capabilities.setCapability("acceptSslCerts", true);

   if (bProxy) {
    final org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
    proxy.setHttpProxy("proxy.ccc-ng-1.eu-central-1.aws.cloud.bmw:8080");
    proxy.setSslProxy("proxy.ccc-ng-1.eu-central-1.aws.cloud.bmw:8080");

    if ("CHROME".equalsIgnoreCase(browser)) {
     final ChromeOptions opsChrome = new ChromeOptions();
     opsChrome.setExperimentalOption("useAutomationExtension", false);
     opsChrome.addArguments("--disable-notifications");
     opsChrome.setCapability(CapabilityType.PROXY, proxy);
     capabilities.setCapability(ChromeOptions.CAPABILITY, opsChrome);
    } else if ("FIREFOX".equalsIgnoreCase(browser)) {
     final FirefoxOptions opsChrome = new FirefoxOptions();
     opsChrome.setCapability(CapabilityType.PROXY, proxy);
     capabilities.setCapability(ChromeOptions.CAPABILITY, opsChrome);
    } else if ("MSIE".equalsIgnoreCase(browser)) {
     final InternetExplorerOptions opsChrome = new InternetExplorerOptions();
     opsChrome.setCapability(CapabilityType.PROXY, proxy);
     capabilities.setCapability(ChromeOptions.CAPABILITY, opsChrome);
     capabilities.setCapability("ignoreProtectedModeSettings", true);
     capabilities.setCapability("IntroduceInstabilityByIgnoringProtectedModeSettings", true);
     capabilities.setCapability("nativeEvents", true);
     capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
    } else if ("EDGE".equalsIgnoreCase(browser)) {
     final EdgeOptions opsChrome = new EdgeOptions();
     opsChrome.setCapability(CapabilityType.PROXY, proxy);
     capabilities.setCapability(ChromeOptions.CAPABILITY, opsChrome);
    }

   }

   try {
    driver = new RemoteWebDriver(new URL(getSeleniumBoxUrl() + "/wd/hub"), capabilities);
    driver.get(System.getProperty("testautomation.targetWebUIUrl"));
    LOG.info("Selenium boxURL::" + getSeleniumBoxUrl());
    LOG.info("Got Remote web driver Current URL:" + driver.getCurrentUrl());
    // LOG.info("Got Remote web driver Page Source:" + driver.getPageSource());
   } catch (final MalformedURLException ex) {
    ex.printStackTrace();
    LOG.info(ex.getMessage());
    System.exit(0);
   }

  }

  else if (TestMachine.equalsIgnoreCase("local"))

  {

   final HashMap<String, Object> Prefs = new HashMap<>();
   switch (browser.toUpperCase()) {
   case "CHROME":
    final ChromeOptions opsChrome = new ChromeOptions();
    opsChrome.addArguments("--disable-notifications");
    opsChrome.setExperimentalOption("prefs", Prefs);
    opsChrome.setExperimentalOption("useAutomationExtension", false);
    final DesiredCapabilities cap = DesiredCapabilities.chrome();
    cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
    cap.setCapability(ChromeOptions.CAPABILITY, opsChrome);
    System.setProperty("webdriver.chrome.driver", "src/test/resources/drivers/chromedriver.exe");
    driver = new ChromeDriver(opsChrome);
    break;
   case "FIREFOX":
    System.setProperty("webdriver.gecko.driver", "src/test/resources/drivers/geckodriver.exe");
    final DesiredCapabilities capability = new DesiredCapabilities();
    capability.setBrowserName("firefox");
    capability.setCapability("marionette", false);
    driver = new FirefoxDriver(capability);
    break;
   case "MSIE":
    final DesiredCapabilities capabilities = new DesiredCapabilities();
    capabilities.setCapability("ignoreProtectedModeSettings", true);
    capabilities.setCapability("IntroduceInstabilityByIgnoringProtectedModeSettings", true);
    capabilities.setCapability("browserName", "internet explorer");
    capabilities.setCapability("nativeEvents", true);
    capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
    System.setProperty("webdriver.ie.driver", "src/test/resources/drivers/IEDriverServer.exe");
    driver = new InternetExplorerDriver(capabilities);
    break;
   default:
    break;
   }

  }
  driver.manage().deleteAllCookies();
  driver.manage().timeouts().setScriptTimeout(DEFAULT_WAIT, TimeUnit.SECONDS);
  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  driver.manage().window().maximize();
  // LOG.info("Before returning driver:" + driver.getPageSource());
  return driver;
 }

 public boolean isChrome() {
  if (driver == null) {
   return false;
  }

  return "chrome".equals(getBrowser().toLowerCase());
 }

 public boolean isFirefox() {
  if (driver == null) {
   return false;
  }

  return "firefox".equals(getBrowser().toLowerCase());
 }

 public boolean isMsIe() {
  if (driver == null) {
   return false;
  }

  return "msie".equals(getBrowser().toLowerCase());
 }

 /**
  * Load system properties.
  */
 private void loadSystemProperties() {
  FileInputStream fileInput = null;
  try {
   final File file = new File(confFile);
   fileInput = new FileInputStream(file);
   final Properties sysProperties = new Properties();
   sysProperties.load(fileInput);
   final Enumeration<Object> keys = sysProperties.keys();
   while (keys.hasMoreElements()) {
    final String key = (String) keys.nextElement();
    final String value = sysProperties.getProperty(key);
    System.setProperty(key, value);
   }
  } catch (final IOException io) {
   StaticElementManager.logMessage(io.toString());
  } catch (final NullPointerException npe) {
   StaticElementManager.logMessage(npe.toString());
  } finally {
   if (fileInput != null) {
    try {
     fileInput.close();
    } catch (final IOException e) {
     StaticElementManager.logMessage(e.toString());
    }
   }
  }
 }

}
