/*
 *
 * 
 * package acceptancetests.base;
 * 
 * import java.sql.*;
 * 
 * public class EdmDbConnect {
 * 
 * public static Connection conection = null;
 * 
 * public static PreparedStatement prepStmt; // static String dbURl =
 * "jdbc:oracle:thin:@tdcaiw10.w10:1547:tdcaiw10"; // // static String userName
 * = "rr_iib"; // // static String password = "GlK1q#DOjOBL";
 * 
 * // CA_DB_Support rr_iib@//tdcaiw10.w10:1547/tdcaiw10
 * 
 * public static void getDBConnection(String applicationCodeEnv) throws
 * ClassNotFoundException, SQLException { // Connection con = null;
 * Class.forName("oracle.jdbc.driver.OracleDriver"); Connection con =
 * DriverManager.getConnection( System.getProperty("testautomation." +
 * applicationCodeEnv + "dbURl").toString(),
 * System.getProperty("testautomation." + applicationCodeEnv +
 * "userName").toString(), System.getProperty("testautomation." +
 * applicationCodeEnv + "password").toString()); conection = con; }
 * 
 * }
 */