package acceptancetests.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;

public class OracleConfiguration {

	private static String username;
	private static String password;
	private static String url;

	public static Connection conection = null;
	public static PreparedStatement prepStmt;

	public static void dataSource(String applicationCodeEnv) throws SQLException {
		username = System.getProperty("testautomation." + applicationCodeEnv + "userName").toString();
		password = System.getProperty("testautomation." + applicationCodeEnv + "password").toString();
		url = System.getProperty("testautomation." + applicationCodeEnv + "dbURl").toString();
		OracleDataSource dataSource = new OracleDataSource();
		dataSource.setUser(username);
		dataSource.setPassword(password);
		dataSource.setURL(url);
		dataSource.setImplicitCachingEnabled(true);
		dataSource.setFastConnectionFailoverEnabled(true);
		conection = dataSource.getConnection();
		// return dataSource;
	}
}