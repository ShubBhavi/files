/*
 *
 */
package acceptancetests.base;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TimeZone;

import org.apache.http.ParseException;
import org.junit.Assert;

import acceptancetests.pages.TestResults;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class InvokeWebService {

	public static String webServiceActualResponse = "";
	public static TestResults testResult = null;
	static int validCount = 0;
	static String sqlQuerryMessageTable = "SELECT * FROM RR_IIB.MESSAGE WHERE REFID LIKE ? AND INSERT_DATETIME >= to_date(?, 'DD-MON-RR hh24.MI.SS')ORDER BY INSERT_DATETIME DESC";
	static String sqlQuerryErrMessageTable = "SELECT * FROM RR_IIB.MESSAGE_ERR WHERE REFID LIKE ? AND INSERT_DATETIME >= to_date(?, 'DD-MON-RR hh24.MI.SS') ORDER BY INSERT_DATETIME DESC";

	public static String CreateDatabaseList(String TestID, String createdTimestamp, Boolean bDynamic,
			List<String> ListDetail, String NodeDetail, String SQLQuery) throws SQLException {
		int validCount = 0;
		boolean validList = false;
		ResultSet rs = null;
		String Start = "";
		String end = "";
		String refId = "";
		OracleConfiguration.prepStmt = OracleConfiguration.conection.prepareStatement(SQLQuery);
		OracleConfiguration.prepStmt.setString(1, "%" + TestID + "%");
		OracleConfiguration.prepStmt.setString(2, createdTimestamp);
		List<String> ListDetailDataBase = new ArrayList<>();
		List<String> ListDetailError = new ArrayList<>();
		rs = OracleConfiguration.prepStmt.executeQuery();
		while (rs.next()) {
			if (!rs.getString("REFID").equals("")) {

				ListDetailDataBase.add(rs.getString("REFID"));
				if (SQLQuery.contains("MESSAGE_ERR")) {
					ListDetailError.add(IIBSupportCommonFunction.CreateErrorPopup(rs.getString("exception_text")));
				}
				validCount = validCount + 1;
				refId = rs.getString("REFID");
				if (bDynamic) {
					Start = refId.substring(0, ListDetail.get(0).indexOf(NodeDetail));
					end = refId.substring(NodeDetail.length() + Start.length());
					refId = Start + NodeDetail + end;
				}
				validList = validateDataFromList(refId, ListDetail);
			}
		}
		CreateReportTable(ListDetail, ListDetailDataBase, ListDetailError);
		return validCount + "," + validList;
	}

	public static List<String> CreateList(String ListDetail) {
		List<String> returnTable = new ArrayList<>();
		for (int j = 0; j < ListDetail.split(",").length; j++) {
			if (IIBSupportCommonFunction.RowID.equals("")) {
				returnTable.add(ListDetail.toString().split(",")[j]);
			} else {
				returnTable.add(ListDetail.split(",")[j].replace("[RowID]", IIBSupportCommonFunction.RowID));
			}
		}
		return returnTable;
	}

	private static void CreateReportTable(List<String> ListDetail, List<String> ListDetailDataBase,
			List<String> ListDetailError) {
		String strTable = "";
		String tablename = " Message";
		String ErrorColumn = "";
		String DatabaseValue = "";
		String ExcelValue = "";
		String ErrorValue = "";
		int tableRow = ListDetail.size();
		Collections.sort(ListDetail);
		Collections.sort(ListDetailDataBase);

		if (ListDetailError.size() > 0) {
			tablename = " Error";
			ErrorColumn = "<td><b>Error Message</b></td>";
		}
		if (ListDetail.size() < ListDetailDataBase.size()) {
			tableRow = ListDetailDataBase.size();
		}
		strTable = "<table class='runtime-table table-striped table'><thead>" + "<tr><td><b>Expected Excel" + tablename
				+ " Data</b></td><td><b>Database" + tablename + " Data</b></td>" + ErrorColumn + "</tr></thead><tbody>";
		for (int row = 0; row < tableRow; row++) {
			ErrorColumn = "<td></td>";
			DatabaseValue = "<td></td>";
			ErrorValue = "";
			if (ListDetail.size() > row) {
				ExcelValue = "<td>" + ListDetail.get(row).toString() + "</td>";
			}
			if (ListDetailDataBase.size() > row) {
				DatabaseValue = "<td>" + ListDetailDataBase.get(row).toString().substring(0,
						ListDetailDataBase.get(row).toString().length() - 20) + "</td>";
			}
			if (ListDetailError.size() > row) {
				ErrorValue = "<td>" + ListDetailError.get(row).toString() + "</td>";
			}
			strTable = strTable + "<tr>" + ExcelValue + DatabaseValue + ErrorValue + "</tr>";
		}

		IIBSupportCommonFunction.addLogs(strTable + "</tbody></table>");

	}

	public static void invokeAPIService(String IibWSUrl, String GetPost) throws ParseException, IOException {
		URL url = new URL(IibWSUrl);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod(GetPost);
		conn.connect();
		String message = "";
		int responsecode = conn.getResponseCode();
		if (responsecode == 200) {
			Scanner sc = new Scanner(url.openStream());
			while (sc.hasNext()) {
				message += sc.nextLine();
			}
			sc.close();
		}
		webServiceActualResponse = message;
	}

	public static void invokeWebService(String IibWSUrl, String iibRequest, boolean externalURL, String ServiceType,
			String strParam) {
		RequestSpecification request = RestAssured.given();
		request.baseUri(IibWSUrl);
		String xml = "";
		if (externalURL) {
			RestAssured.useRelaxedHTTPSValidation();
		}

		Map<String, String> authhdrs = new HashMap<>();
		authhdrs.put("SOAPAction", "Define");
		if (!strParam.equals("")) {
			for (int intC = 0; intC < strParam.split(";").length / 2; intC++) {
				authhdrs.put(strParam.split(";")[intC * 2], strParam.split(";")[(intC * 2) + 1].trim());
			}
		}
		xml = request.given().headers(authhdrs).contentType("application/soap+xml; charset=UTF-8;").body(iibRequest)
				.when().post("").andReturn().asString();
		webServiceActualResponse = xml;
	}

//	public static String getAuthToken() {
//		RequestSpecification request = RestAssured.given().auth()
//                .preemptive()
//                .basic("58abdad8-b275-4638-b490-8589c5b8d6d4", "MLA6ec0WSFryJazXwLdJa8fg4gwmp6xac1BjzO7R");
////		Map<String, String> authhdrs = new HashMap<>();
////		authhdrs.put("SOAPAction", "Define");
//		request.baseUri("https://auth-i.bmw.com/auth/oauth2/realms/root/realms/machine2machine");
//		Response xml = request.contentType("application/x-www-form-urlencoded")
//				.post("/access_token?grant_type=client_credentials&scope=machine2machine%20client_58abdad8-b275-4638-b490-8589c5b8d6d4").then().extract().response();
//		return "";
//	}

	public static boolean validateDataFromList(String Id, List<String> TableList) {
		boolean isValid = false;
		Id = Id.substring(0, Id.length() - 20);
		if (TableList.contains(Id)) {
			validCount++;
		}
		if (validCount == TableList.size()) {
			isValid = true;
		}
		return isValid;
	}

	public static void verifyMessageAndError(ArrayList<String> strArray, Date beforeWSInvokeDate, String TCID,
			Double Inboundcount, Double outboundcount, Double errorcount, boolean bDynamic) throws SQLException {
		ResultSet rs = null;
		boolean finalResult = true;
		String VerifyLog = "";
		int REFID_COUNT = 0;
		int errorRefIdCount = 0;
		boolean isMessagerefIdValid = false;
		boolean isErrMessagerefIdValid = false;
		List<String> MessageTableRefIdList = new ArrayList<>();
		List<String> ErrMessageTableRefIdList = new ArrayList<>();

		try {

			TimeZone.getTimeZone("Canada/Eastern");
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-YY HH:mm:ss");
			dateFormat.setTimeZone(TimeZone.getTimeZone("Canada/Eastern"));
			String createdTimestamp = dateFormat.format(beforeWSInvokeDate);

			if (null != strArray.get(IIBSupportCommonFunction.Message_Table_Ref_ID)) {
				MessageTableRefIdList = CreateList(
						strArray.get(IIBSupportCommonFunction.Message_Table_Ref_ID).toString());
			}

			VerifyLog = CreateDatabaseList(strArray.get(IIBSupportCommonFunction.TestRefD).trim(), createdTimestamp,
					bDynamic, MessageTableRefIdList, strArray.get(IIBSupportCommonFunction.BodID).toString(),
					sqlQuerryMessageTable);
			REFID_COUNT = Integer.parseInt(VerifyLog.split(",")[0]);
			isMessagerefIdValid = Boolean.parseBoolean(VerifyLog.split(",")[1]);
			if (REFID_COUNT > 0)
				IIBSupportCommonFunction.addLogs("Pass - Message Table EDM logs Pattern verified." + "");
			else {
				IIBSupportCommonFunction.addLogs("Fail - Unable to verify Message Table EDM logs ." + "");
				finalResult = false;
			}
			if (isMessagerefIdValid) {
				IIBSupportCommonFunction.addLogs("Pass - Message table REFID Verified" + "");
			} else {
				IIBSupportCommonFunction.addLogs("Fail - Message table REFID is not as per expected" + "");
				finalResult = false;
			}

			if (null != strArray.get(IIBSupportCommonFunction.Error_Message_Table_Ref_ID)
					&& strArray.get(IIBSupportCommonFunction.Error_Message_Table_Ref_ID).trim() != "") {
				// IIBSupportCommonFunction.addLogs("<b>Error List from Input Excel</b>");
				ErrMessageTableRefIdList = CreateList(
						strArray.get(IIBSupportCommonFunction.Error_Message_Table_Ref_ID).toString());
			}
			validCount = 0;
			if (errorcount > 0) {
				errorRefIdCount = 0;

				VerifyLog = CreateDatabaseList(strArray.get(IIBSupportCommonFunction.TestRefD).trim(), createdTimestamp,
						bDynamic, ErrMessageTableRefIdList, strArray.get(IIBSupportCommonFunction.BodID).toString(),
						sqlQuerryErrMessageTable);
				errorRefIdCount = Integer.parseInt(VerifyLog.split(",")[0]);
				isErrMessagerefIdValid = Boolean.parseBoolean(VerifyLog.split(",")[1]);

				if (errorRefIdCount > 0 || strArray.get(IIBSupportCommonFunction.Error_Message_Table_Ref_ID).equals(""))
					IIBSupportCommonFunction.addLogs("Pass - Error Message Table EDM logs Pattern verified." + "");
				else {
					IIBSupportCommonFunction.addLogs("Fail - Unable to verify MessageErr Table EDM logs." + "");
					finalResult = false;
				}
				if (isErrMessagerefIdValid && ErrMessageTableRefIdList.size() == errorRefIdCount) {
					IIBSupportCommonFunction.addLogs("Pass - Error Message  table REFID Verified." + "");
				} else {
					IIBSupportCommonFunction.addLogs("Fail - Error Message table REFID is not as per expected." + "");
					finalResult = false;
				}
			}
			if (Inboundcount + outboundcount == REFID_COUNT && errorcount == errorRefIdCount) {
				IIBSupportCommonFunction.addLogs("Pass - All the Inbound, Outbound and error EDM logs verified." + "");
			} else {
				IIBSupportCommonFunction
						.addLogs("Fail - All the Inbound, Outbound and error EDM logs are not as per expected." + "");
				finalResult = false;
			}
			validCount = 0;
			REFID_COUNT = 0;
			errorRefIdCount = 0;
		} catch (Exception e) {
			IIBSupportCommonFunction.addLogs(e.getLocalizedMessage());
			Assert.assertTrue(false);
		} finally {
			if (null != rs)
				rs.close();
		}
		Assert.assertTrue(finalResult);
	}

}
