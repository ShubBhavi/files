/*
 *
 */
package acceptancetests.steps;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;

import org.junit.Assert;
import org.junit.AssumptionViolatedException;

import acceptancetests.base.ExcelUtils;
import acceptancetests.base.IIBSupportCommonFunction;
import acceptancetests.base.InvokeWebService;
import acceptancetests.base.OracleConfiguration;
import acceptancetests.base.StaticElementManager;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class IIBStepDefination {

	static Date beforeWSInvokeDate;
	String applicationCode;
	boolean externalURL = false;
	String env = "";
	String ResponseType = "XML";
	// @Given("^The Test Data is setup in Master Sheet, Verify appliation
	// \"([^\"]*)\"$ using \"([^\"]*)\"$ URL")
	// public void cacheMasterExcel(String applicationCode, String TestURL)
	// throws IOException {
	// IIBSupportCommonFunction.RowID = "";
	// this.applicationCode = applicationCode;
	// if (TestURL.equalsIgnoreCase("external")) {
	// externalURL = true;
	// }
	// }

	@When("The connection is Established with EDM Database")
	public void getEDMDBConnection() throws IOException {
		try {
			ExcelUtils exUtil = new ExcelUtils(
					System.getProperty("user.dir")
							+ "\\src\\test\\resources\\IIBScenarioMaster.xlsx",
					"Summary");
			ArrayList<String> arrType = exUtil.findCell(applicationCode, 0, 5,
					5);
			// String[][] arrSummary = new String[1][exUtil.getData("0", "0",
			// "Summary").length];
			if (null == OracleConfiguration.conection) {
				OracleConfiguration.dataSource(arrType.get(0) + env);
				IIBSupportCommonFunction
						.setTestRunnerOutput("<B>Connection URL</B> : "
								+ System.getProperty("testautomation."
										+ arrType.get(0) + env + "dbURl")
								+ "");
				IIBSupportCommonFunction
						.setTestRunnerOutput("<B>User</B> : "
								+ System.getProperty("testautomation."
										+ arrType.get(0) + env + "userName")
								+ "");
				if (OracleConfiguration.conection != null) {
					IIBSupportCommonFunction.setTestRunnerOutput(
							"Pass - Connection is Established with EDM Database.");
				} else {
					IIBSupportCommonFunction.setTestRunnerOutput(
							"Fail - Connection is not Established with EDM Database.");
				}
			}
		} catch (Exception e) {
			IIBSupportCommonFunction.setTestRunnerOutput(
					"Fail - Connection is not Established with EDM Database.");
			Assert.assertTrue(false);
		}
	}

	@And("The API service is invoked for {string}")
	public void invokeTheAPIServiceFor(String strTestID) throws Throwable {
		ResponseType = "JSON";
		ArrayList<String> strArray = IIBSupportCommonFunction.getExcelRowData(
				applicationCode, strTestID,
				IIBSupportCommonFunction.JavaMaxColNum);
		if (!strArray.isEmpty()) {
			beforeWSInvokeDate = new Date();
			String sURL = strArray.get(IIBSupportCommonFunction.Url);
			if (externalURL) {
				sURL = strArray.get(IIBSupportCommonFunction.ExternalUrl);
			}
			try {
				InvokeWebService.invokeAPIService(
						sURL + strArray
								.get(IIBSupportCommonFunction.RequestParam),
						strArray.get(IIBSupportCommonFunction.GetPost));
			} catch (Exception ex) {
				InvokeWebService.invokeAPIService(
						sURL + strArray
								.get(IIBSupportCommonFunction.RequestParam),
						strArray.get(IIBSupportCommonFunction.GetPost));
			}
			StaticElementManager.staticWait(10);
			IIBSupportCommonFunction
					.setTestRunnerOutput("API URL : " + sURL + ".");
			IIBSupportCommonFunction
					.setTestRunnerOutput("<b>Expected Output " + ResponseType
							+ " Response</b> : <a href='../html/Response/"
							+ strTestID + "." + ResponseType
							+ "' target=\"_blank\">" + strTestID + "</a>");
			TimeZone.getTimeZone("Canada/Eastern");
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"dd-MMM-YY HH:mm:ss");
			dateFormat.setTimeZone(TimeZone.getTimeZone("Canada/Eastern"));
			IIBSupportCommonFunction.setTestRunnerOutput(
					"Pass - Invoke the web service successfully for <b>"
							+ strTestID + "</b> @ "
							+ dateFormat.format(beforeWSInvokeDate) + ".");
		}
	}

	@And("The {string} service is invoked for {string} with Request {string} get Response {string}")
	public void invokeTheWebServiceFor(String ServiceType, String strTestID,
			String requestfiletype, String responsefiletype) throws Throwable {
		// ResponseType = requestfiletype;
		ArrayList<String> strArray = IIBSupportCommonFunction.getExcelRowData(
				applicationCode, strTestID, IIBSupportCommonFunction.MaxColNum);
		if (!strArray.isEmpty()) {
			String iibRequest = IIBSupportCommonFunction.getIibRequest(
					strArray.get(IIBSupportCommonFunction.TCID).toString(),
					strArray.get(IIBSupportCommonFunction.NodeDetailRequest)
							.toString(),
					requestfiletype);
			beforeWSInvokeDate = new Date();
			String sURL = strArray.get(IIBSupportCommonFunction.Url);
			if (externalURL) {
				sURL = strArray.get(IIBSupportCommonFunction.ExternalUrl);
			}
			try {
				InvokeWebService.invokeWebService(sURL, iibRequest, externalURL,
						ServiceType,
						strArray.get(IIBSupportCommonFunction.Parameter));
			} catch (Exception ex) {
				InvokeWebService.invokeWebService(sURL, iibRequest, externalURL,
						ServiceType,
						strArray.get(IIBSupportCommonFunction.Parameter));
			}
			StaticElementManager.staticWait(5);
			IIBSupportCommonFunction
					.setTestRunnerOutput("IIB URL : " + sURL + ".");
			IIBSupportCommonFunction.setTestRunnerOutput(
					"<b>Expected Output " + responsefiletype
							+ " Response</b> : <a href='../html/Response/"
							+ strTestID + "." + responsefiletype
							+ "' target=\"_blank\">" + strTestID + "</a>");
			TimeZone.getTimeZone("Canada/Eastern");
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"dd-MMM-YY HH:mm:ss");
			dateFormat.setTimeZone(TimeZone.getTimeZone("Canada/Eastern"));
			IIBSupportCommonFunction.setTestRunnerOutput(
					"Pass - Invoke the web service successfully for <b>"
							+ strTestID + "</b> @ "
							+ dateFormat.format(beforeWSInvokeDate) + ".");
		}
	}

	@Given("The Test Data is setup in Master Sheet, Verify appliation {string} using {string} URL on {string} Environment")
	public void the_test_data_is_setup_in_master_sheet_verify_appliation_using_url(
			String applicationCode, String TestURL, String Environment) {
		IIBSupportCommonFunction.RowID = "";
		this.applicationCode = applicationCode;
		if (TestURL.equalsIgnoreCase("external")) {
			externalURL = true;
		}
		env = Environment;
	}

	@Then("Validate the REST {string} Responce for {string}")
	public void validate_the_api_responce_for(String ResponseFileType,
			String strTestID) {

		ArrayList<String> strArray = IIBSupportCommonFunction.getExcelRowData(
				applicationCode, strTestID,
				IIBSupportCommonFunction.JavaMaxColNum);
		if (!strArray.isEmpty()) {
			try {
				if (IIBSupportCommonFunction.jsonCompare(
						IIBSupportCommonFunction.getExpectedIibResponse(
								strTestID, "", ResponseFileType),
						InvokeWebService.webServiceActualResponse)) {
					IIBSupportCommonFunction.addLogs(
							"Pass - Successfully verified Actual and expected result are same."
									+ "");
				} else {
					BufferedWriter writer = new BufferedWriter(
							new FileWriter(System.getProperty("user.dir")
									+ "\\target\\Result\\html\\Response\\"
									+ strTestID + "- Actual."
									+ ResponseFileType));
					writer.write(InvokeWebService.webServiceActualResponse);
					writer.close();
					IIBSupportCommonFunction.setTestRunnerOutput(
							"<b>Actual Output " + ResponseFileType
									+ " Response</b> : <a href='../html/Response/"
									+ strTestID + "- Actual." + ResponseFileType
									+ "' target=\"_blank\">" + strTestID
									+ "</a>");
					IIBSupportCommonFunction
							.addLogs("Fail - Response doesnt match." + "");
					Assert.assertTrue(false);
				}
			} catch (Exception e) {
				IIBSupportCommonFunction.setTestRunnerOutput(
						"<b>Actual Output " + ResponseFileType
								+ " Response</b> : <a href='../html/Response/"
								+ strTestID + "- Actual." + ResponseFileType
								+ "' target=\"_blank\">" + strTestID + "</a>");
				IIBSupportCommonFunction
						.addLogs("Fail - Response doesnt match." + "");
				IIBSupportCommonFunction.addLogs(strTestID
						+ " could not validate the Response received from IIB Service with the expected response code.");
				throw new AssumptionViolatedException(strTestID
						+ " could not validate the Response received from IIB Service with the expected response code.");
			}

		}
	}

	@And("Validate the EDM Logs with dynamic BodID for {string}")
	public void validateTheEDMLogscountsFor(String strTestID) throws Throwable {
		ArrayList<String> strArray = IIBSupportCommonFunction.getExcelRowData(
				applicationCode, strTestID, IIBSupportCommonFunction.MaxColNum);
		if (!strArray.isEmpty()) {
			try {
				InvokeWebService.verifyMessageAndError(strArray,
						beforeWSInvokeDate,
						strArray.get(IIBSupportCommonFunction.TCID).toString(),
						Double.parseDouble(
								strArray.get(IIBSupportCommonFunction.Inbound)),
						Double.parseDouble(strArray
								.get(IIBSupportCommonFunction.Outbound)),
						Double.parseDouble(
								strArray.get(IIBSupportCommonFunction.Error)),
						true);
				beforeWSInvokeDate = null;
			} catch (Exception e) {
				throw new AssumptionViolatedException(strArray
						.get(IIBSupportCommonFunction.TCID).toString()
						+ " could not verify logs with the expected Ref-Id and count logs.");
			}
		}
	}

	// @And("Validate the EDM Logs for {string}")
	// public void validateTheEDMLogsFor(String strTestID) throws Throwable {
	// ArrayList<String> strArray =
	// IIBSupportCommonFunction.getExcelRowData(applicationCode, strTestID);
	// if (!strArray.isEmpty()) {
	// try {
	// InvokeWebService.verifyMessageAndError(strArray, beforeWSInvokeDate,
	// strArray.get(IIBSupportCommonFunction.TCID).toString(),
	// Double.parseDouble(strArray.get(IIBSupportCommonFunction.Inbound)),
	// Double.parseDouble(strArray.get(IIBSupportCommonFunction.Outbound)),
	// Double.parseDouble(strArray.get(IIBSupportCommonFunction.Error)), false);
	// beforeWSInvokeDate = null;
	// } catch (Exception e) {
	// throw new
	// AssumptionViolatedException(strArray.get(IIBSupportCommonFunction.TCID).toString()
	// + " could not verify logs with the expected Ref-Id and count logs.");
	// }
	// }
	// }

	@Then("Validate the SOAP {string} Responce for {string}")
	public void validateTheIIBResponceFor(String ResponseFileType,
			String strTestID) throws Throwable {
		StaticElementManager.staticWait(6);
		ArrayList<String> strArray = IIBSupportCommonFunction.getExcelRowData(
				applicationCode, strTestID, IIBSupportCommonFunction.MaxColNum);
		if (!strArray.isEmpty()) {
			try {
				if (IIBSupportCommonFunction.xmlCompare(IIBSupportCommonFunction
						.getExpectedIibResponse(strTestID, strArray.get(
								IIBSupportCommonFunction.NodeDetailResponse)
								.toString(), ResponseFileType),
						InvokeWebService.webServiceActualResponse)) {
					IIBSupportCommonFunction.addLogs(
							"Pass - Successfully verified Actual and expected result are same."
									+ "");
				} else {
					BufferedWriter writer = new BufferedWriter(
							new FileWriter(System.getProperty("user.dir")
									+ "\\target\\Result\\html\\Response\\"
									+ strTestID + "- Actual."
									+ ResponseFileType));
					writer.write(InvokeWebService.webServiceActualResponse);
					writer.close();
					IIBSupportCommonFunction.setTestRunnerOutput(
							"<b>Actual Output XML Response</b> : <a href='../html/Response/"
									+ strTestID + "- Actual." + ResponseFileType
									+ "' target=\"_blank\">" + strTestID
									+ "</a>");
					IIBSupportCommonFunction
							.addLogs("Fail - Response doesnt match." + "");
					Assert.assertTrue(false);
				}
			} catch (Exception e) {
				BufferedWriter writer = new BufferedWriter(
						new FileWriter(System.getProperty("user.dir")
								+ "\\target\\Result\\html\\Response\\"
								+ strTestID + "- Actual." + ResponseFileType));
				writer.write(InvokeWebService.webServiceActualResponse);
				writer.close();
				IIBSupportCommonFunction.setTestRunnerOutput(
						"<b>Actual Output XML Response</b> : <a href='../html/Response/"
								+ strTestID + "- Actual." + ResponseFileType
								+ "' target=\"_blank\">" + strTestID + "</a>");
				IIBSupportCommonFunction.addLogs(strTestID
						+ " could not validate the Response received from IIB Service with the expected response code.");
				// throw new AssumptionViolatedException(
				// strTestID + " could not validate the Response received from
				// IIB Service with the expected response code.");
				Assert.assertTrue(false);
			}

		}
	}

}
